package com.example.CodeCraft.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name= "Estudiante")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Estudiante {
    @Id
    private int id;
    @Column(nullable = false)
    private String nombre;
    @Column(nullable = false, length = 25)
    private String apellido;
    @Column(nullable = false, length = 25)
    private int rut;
    @Column(nullable = false)
    private int telefono;
    @Column(nullable = false)
    private String correo;
}
