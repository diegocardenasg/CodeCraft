package com.example.CodeCraft;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodeCraftApplicationTests {

	@Test
	void contextLoads() {
	}

}
